public class Vehicle2010 extends Vehicle{
  
  
  public Vehicle2010(){
    
  }
  
  public void moveLowerLeft(){
    moveDown();
    moveLeft();
  }
  
  public String getPosition(){
    return "("+x+","+y+")";
  }
  
  public void moveUpperRight(){
    moveUp();
    moveRight();
  }
  
  public void moveLowerRight(){
    moveDown();
    moveRight();
  }
}
                             