public class Dog extends Animal{
  String breed;
  public Dog(String name,int age,String color,String breed){
    super(name,age,color);
    this.breed=breed;
  }
  
  public String dogInfo(){
    return info()+"Breed: "+breed;
  }
  
  public void makeSound(){
    System.out.println(color+" color "+name+" is barking");
  }
}
