public class Mage extends GameCharacter{
  
  public int intelligence;
  public int mana;
  
  public Mage(String name,int level,int intelligence,int mana,String weaponType){
    super(name,level,weaponType);
    this.intelligence=intelligence;
    this.mana=mana;
     allCharacters[characterCount]=name;
    characterCount++;
  }
  
  public String toString(){
    return "A new mage came to live \n"+getCharacterInfo()+"\nCharacter Type: Mage\nWeapon: "+weaponType+"\nIntelligence: "+intelligence+", Mana: "+mana+"\nTotal Damage: "+totalDamage;
  }
  
  public void calculateDamage(){
    totalDamage=(getLevel()*intelligence)+(mana*10);
  }
  
  
      
}
  