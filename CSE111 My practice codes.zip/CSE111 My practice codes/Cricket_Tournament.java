public class Cricket_Tournament extends Tournament{
  public String type;
  public int teams;
  public Cricket_Tournament(){
  }
  
  public String info(){
    return "Cricket "+getName()+ "\nNumber of Teams: "+teams+"\nTypes: "+type;
  }
  
  public Cricket_Tournament(String name,int teams,String type){
    super(name);
    this.teams=teams;
    this.type=type;
  }
}
  
    