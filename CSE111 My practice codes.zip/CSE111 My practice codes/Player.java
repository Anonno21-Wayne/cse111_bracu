public class Player extends SportsPerson{
 int match;
 int goals;
  double ratio;
  public Player(String teamName,String name,String role,int goals,int match){
    super(teamName,name,role);
    this.goals=goals;
    this.match=match;
    earningPerMatch=(goals*1000)+(match*10);
  }
  
  public void calculateRatio(){
    ratio=(double)goals/match;
  }
  

  
  public void printDetails(){
    System.out.println(getNameTeam());
    System.out.println("Team Role: "+role);
    System.out.println("Total Goal: "+goals+" , Total Played: "+match);
    System.out.println("Goal Ratio: "+ratio);
    System.out.println("Match Earning: "+earningPerMatch+"K");
  }
}
    
                       
    