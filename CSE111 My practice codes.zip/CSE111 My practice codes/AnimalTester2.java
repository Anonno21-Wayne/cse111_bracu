public class AnimalTester2 {
public static void main(String args[]){
Animal a1 = new Animal();
System.out.println("1-------------");
a1.details();
System.out.println("2-------------");
Cow c1 = new Cow();
c1.name = "Pammy";
System.out.println("3-------------");
System.out.println("Name: " + c1.getName());
c1.details();
System.out.println("4-------------");
c1.updateSound("Moo");
System.out.println("5-------------");
c1.details();
}
}