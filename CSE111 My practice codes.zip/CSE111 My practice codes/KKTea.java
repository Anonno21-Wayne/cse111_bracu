public class KKTea extends Tea{
  public int teaBags;
  public int weight=100;
 static int regularCount;
  
  public static int totalSaleCount;
  
  public KKTea(int price,int teaBags){
    super("KK Regular Tea",price);
    this.teaBags=teaBags;
    this.weight=teaBags*2;
    
  }
  
  public void productDetail(){
    super.productDetail();
    System.out.println("Weight: "+weight+", Tea Bags: "+teaBags);
  }
  
  public static void totalSales(){
    System.out.println("Total Sales: "+totalSaleCount);
    System.out.println("KK Regular Tea: "+regularCount);
    if(KKFlavouredTea.flavouredCount>0){
    System.out.println("KK Flavoured Tea: "+KKFlavouredTea.flavouredCount);
  }
  }
  
  public static void updateSoldStatusRegular(KKTea obj){
   obj.status=true;
    regularCount++;
    totalSaleCount++;
  }
}

  
    
    
  
  
  
  
    
  
    