public class Electronics extends Product{
  int warranty;
  public Electronics(String productName,double price,int warranty){
    super(productName,price);
    this.warranty=warranty;
  }
  
  public void displayInfo(){
    System.out.println("Electronics: "+productName+", Price: $"+price+" Warranty: "+warranty+" months");
  }
  
  public void displayInfo(boolean showPrice){
    if(!showPrice){
      System.out.println("Electronics: "+productName+" , Warranty: "+warranty+" months");
    }
  }
}
    