public class Warrior extends GameCharacter{
  public int strength;
  public int armor;
  
  
  public Warrior(String name,int level,int strength,int armor,String weaponType){
    super(name,level,weaponType);
    this.strength=strength;
    this.armor=armor;
    System.out.println("A new warrior has arrived");
    allCharacters[characterCount]=name;
    characterCount++;
  }
  
  public String toString(){
    return getCharacterInfo()+"\nCharacter Type: Warrior \nWeapon: "+weaponType+"\nStrength: "+strength+", Armor: "+armor+"\nTotalDamage: "+totalDamage;
  }
  
  public void calculateDamage(){
    totalDamage=(getLevel()*strength)+(armor*50);
  }


}

                                 
  