public class PremiumRide extends Ride{
  public static int count;
 public static int sc=50;
 public String id="";
  public boolean surge;
  public boolean discount;
  
  public PremiumRide(int distance,boolean surge){
    super(distance);
    this.surge=surge;
    count++;
    id+=count+"-"+distance;
  }
  
  public String toString(){
    String s1="";
    s1=super.toString()+"\nID: "+id+"\nService Charge: "+sc+"\nSurge: "+surge+"\nDiscount: "+discount;
  return s1;
  }
  
  
  public double calculateFare(){
    double fare=super.calculateFare();
    fare+=sc;
    if(surge){
      fare+=(fare*20)/100.0;
    }
    return fare;
  }
  
  public double calculateFare(int d){
    this.discount=true;
    return calculateFare()-d;
  }
  
  public String getId(){
    return id;
  }
}