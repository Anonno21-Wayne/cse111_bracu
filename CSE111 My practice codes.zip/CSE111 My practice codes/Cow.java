public class Cow extends Animal{
  String name;
  String sound;
  
  public Cow(){
    this.name=name;
    this.sound=sound;
    System.out.println("The cow says hello!");
  }
  
  public String getName(){
    return name;
  }
  
  
  public void details(){
    
    super.details();
  }
  
  public void updateSound(String newSound){
    super.sound=newSound;
  }
}
  