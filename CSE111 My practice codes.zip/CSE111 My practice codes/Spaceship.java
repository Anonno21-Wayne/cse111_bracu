public class Spaceship{
  public String sname;
  public int capacity;
  public int cweight=0;
  public Cargo[]cargos=new Cargo[100];
  public int count;
  public Spaceship(String s,int x){
    sname=s;
    capacity=x;
  }
  public void loadCargo(Cargo s){
    if(s.getweight()<=capacity){
      cargos[count++]=s;
      cweight+=s.getweight();
    }
    else{
      System.out.println("Can't load "+s.getName()+" inside "+sname+".Exceeds capacity by "+(s.getweight()+cweight-capacity));
    }
  }
  public void displayDetails(){
    System.out.println("Spaceship Name:"+this.sname);
    System.out.println("Capacity:"+capacity);
    System.out.println("Current capacity:"+cweight);
    System.out.print("Cargo:");
    for(int i=0;i<count;i++){
      Cargo s=cargos[i];
      System.out.print(s.getName()+" ");
    }
  }
}
    