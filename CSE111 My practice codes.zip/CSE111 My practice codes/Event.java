public class Event{
  private String name;
  static Event event[]=new Event[5];
  String date;
  static int count;
  
  public Event(String name,String date){
    if(count<5){
    this.name=name;
    this.date=date;
    event[count]=this;
    count++;
  }
  }
  
  public String getName(){
    return name;
  }
  
  public String details(){
    return "Name: "+name+"\nDate: "+date;
  }
  
  public static void allEventInfo(){
    System.out.println("Total Events: "+count);
    System.out.println("Event Details: ");
    for(int i=0;i<count;i++){
      System.out.println("Event: "+(i+1)+": ");
      System.out.println(event[i].details());
      
    }
  }
}
  
  
      
    
 