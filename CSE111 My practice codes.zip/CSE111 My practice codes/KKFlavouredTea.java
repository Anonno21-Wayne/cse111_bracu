public class KKFlavouredTea extends KKTea{
  static int flavouredCount;
  
  public KKFlavouredTea(String name,int price,int teaBags){
    super(price,teaBags);
    this.name="KK "+name+" Tea";
  }
  
  public void productDetail(){
    super.productDetail();
  }
  
  public static void updateSoldStatusFlavoured(KKFlavouredTea obj){
    obj.status=true;
    totalSaleCount++;
    flavouredCount++;
  }
}
  
  
    
    
  
    
  