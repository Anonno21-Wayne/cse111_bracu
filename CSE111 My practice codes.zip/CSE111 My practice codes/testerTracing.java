public class testerTracing{
  public static void main(String [] args){
    B b1=new B();
    new B();
    B b2=new B(b1);
    b1.methodB(3,2);
  }
}